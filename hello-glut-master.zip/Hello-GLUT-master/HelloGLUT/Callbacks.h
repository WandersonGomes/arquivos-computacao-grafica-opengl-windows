#pragma once

/* Callback function declarations */
void keyboard(unsigned char key, int x, int y);
void display(void);
